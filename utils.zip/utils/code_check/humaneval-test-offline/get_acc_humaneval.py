import os
import sys
import json
import contextlib
import signal
import io
import multiprocessing
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed

from execution_wei import check_correctness
import re
def humaneval_postprocess_v2(text: str) -> str:
    """This is an advanced version of previous postprocess to handle more
    situations, better to use this one."""
    try:
        # for chatGLM raw text
        text = eval(text)
    except Exception:
        pass
    if not isinstance(text, str):
        text = str(text)
    text = text.lstrip('\n')
    if '```' in text:
        blocks = re.findall(r'```(.*?)```', text, re.DOTALL)
        if len(blocks) == 0:
            text = text.split('```')[1]  # fall back to default strategy
        else:
            text = blocks[0]  # fetch the first code block
            if not text.startswith('\n'):  # in case starting with ```python
                text = text[max(text.find('\n') + 1, 0):]
    if text.strip().startswith('from') or text.strip().startswith('import'):
        def_idx = text.find('def')
        if def_idx != -1:
            text = text[max(text.find('\n', def_idx) + 1, 0):]
    # remove empty lines
    text = '\n'.join([line for line in text.split('\n') if line != ''])
    text = text.lstrip('\n')
    if text.strip().startswith('def'):
        text = '\n'.join(text.split('\n')[1:])
    # deal with the indentation error
    if text.startswith(' '):
        text = '    ' + text.lstrip()
    else:
        text = '\n'.join(['    ' + line for line in text.split('\n')])
    text = text.split('\n')

    # If number of leading space reduces, we assume that the code block ends.
    min_leading_space = None
    end_index = None
    for index, line in enumerate(text):
        if line.strip() == '' or line.strip()[0] in ["'", '"', '#']:
            continue
        current_leading_space = len(line.rstrip()) - len(line.strip())
        if min_leading_space is None:
            min_leading_space = current_leading_space
        elif current_leading_space < min_leading_space:
            end_index = index
            break
    if end_index is not None:
        text = '\n'.join(text[:end_index])
    else:
        text = '\n'.join(text)
    return text

def keyword_search(answer, start, end):
    result = re.search(rf'{start}(.*?){end}', answer, re.DOTALL)
    if result:
        code = result.group(1).replace("```python", "").replace("```", "").replace('python\n', '')
        return code
    return None

def code_search(answer):
    keyword = [
        ['【代码开始】', '【代码结束】'],
        ['【代码开始】', '【代码结束'],
        ['```python', '```'],
        ['### 代码开始', '### 代码结束'],
        ['###代码开始', '###代码结束'],
    ]
    for start, end in keyword:
        code = keyword_search(answer, start, end)
        if code is not None:
            code = code.split('# 测试用例')[0].split('# 测试代码')[0]
            return code
    return None

def get_code_bigcode(text):
    implementation = text.split("[Implementation]")[1]
    code1=code_search(implementation)

    test = implementation.split("[Tests]")[1]
    code2 = code_search(test)

    return code1, code2


def get_acc_humaneval(gt,res,method='openai'):
    matched=0
    miss_gt=0
    test_cases={}

    with open(gt) as f:
        for line in f.readlines():
            info=json.loads(line)
            task_id=info["task_id"]
            test_cases.update({task_id:info})

    # fn=open("humaneval.jsonl",'w')
    passed=0
    assertion_error=0
    failed=0
    other_err=0

    diff=0
    fd=open("diff.jsonl",'w')
    with open(res) as f:
        data=json.load(f)
        for key,value in data.items():
            question=value["origin_prompt"][-1]["prompt"].replace("<|im_start|>user\n",'').replace("<|im_end|>\n",'').replace("\nPlease reason step by step, and put your final answer within \\boxed{}.",'')

            prediction=value["prediction"]
            gold=value["gold"]

            if gold not in test_cases:
                miss_gt+=1
                continue
            gt_info =test_cases[gold]

            code =code_search(prediction)
            head = "from typing import List\n"
            # check_code = head+code + "\n" + gt_info["test"] + "\n" + f"check({gt_info['entry_point']})"
            if code:
                check_code = code + "\n" + gt_info["test"] + "\n" + f"check({gt_info['entry_point']})"
                res = check_correctness(check_code, task_id='', timeout=10.0)
            else:
                res = {"tsak_id": "", "passed": False, "result": "failed: miss code"}

            prompt=gt_info["prompt"]
            completion=humaneval_postprocess_v2(prediction)
            check_code2 = prompt +completion +"\n" + gt_info["test"] + "\n" + f"check({gt_info['entry_point']})"
            res2 = check_correctness(check_code2, task_id='', timeout=10.0)
            if res!=res2:
                # print(f"diff {diff}, wei_res: {res['result']},\t\t wei_res: {res2['result']}")
                print(f"diff {diff:<3}, full_code_res: {res['result']:<50}, opencompass_res: {res2['result']:<20}")
                print(f"{gold}")
                diff+=1
                tmp_data={
                    "res_wei": res,
                    "res_cat": res2,
                    "full_code": check_code,
                    "cat_code": check_code2,

                }
                fd.write(json.dumps(tmp_data,ensure_ascii=False)+'\n')
                # import pdb
                # pdb.set_trace()

            if method=='openai':
                res = res2
            if res["passed"]:
                passed+=1
            else:
                # print(res)
                if res["result"]=="assertion_error":
                    assertion_error+=1
                elif res["result"].startswith("failed:"):
                    failed+=1
                    # print("="*100)
                    # print(res["result"])
                    # print(check_code)
                else:
                    other_err+=1
    score = passed / len(data) * 100
    print(f"{method}, passed:{passed}, assertion_error: {assertion_error}, failed:{failed}, other_err:{other_err}, score:{score:.2f}")

    print("diff:", diff)

gt='/mnt/afs_1/weihuaqiang/to_1424/test/opencompass/jobs/wei_math/humaneval-test-offline/human-eval-v2-20210705.jsonl'
res=sys.argv[1]
# res='/data2/industry_project/LLM/Code/test/humaneval/results/C2.37/openai_humaneval.json'
#get_acc_humaneval(gt,res,method='openai')
get_acc_humaneval(gt,res,method='wei')
