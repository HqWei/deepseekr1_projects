import os
import re
import json
from tqdm import tqdm
import sys
from tabulate import tabulate
from utils.math_judge.grader import math_equal
def score(predictions, references):
    if len(predictions) != len(references):
        return {
            'error': 'predictions and references have different '
                     'length'
        }
    correct = 0
    count = 0
    details = []
    for i, j in zip(predictions, references):
        detail = {'pred': i, 'answer': j, 'correct': False}
        count += 1
        if is_equiv(i, j):
            correct += 1
            detail['correct'] = True
        details.append(detail)
    result = {'accuracy': 100 * correct / count, 'details': details}
    return result

def fix_fracs(string):
    substrs = string.split('\\frac')
    new_str = substrs[0]
    if len(substrs) > 1:
        substrs = substrs[1:]
        for substr in substrs:
            new_str += '\\frac'
            if len(substr) > 0 and substr[0] == '{':
                new_str += substr
            else:
                try:
                    assert len(substr) >= 2
                except AssertionError:
                    return string
                a = substr[0]
                b = substr[1]
                if b != '{':
                    if len(substr) > 2:
                        post_substr = substr[2:]
                        new_str += '{' + a + '}{' + b + '}' + post_substr
                    else:
                        new_str += '{' + a + '}{' + b + '}'
                else:
                    if len(substr) > 2:
                        post_substr = substr[2:]
                        new_str += '{' + a + '}' + b + post_substr
                    else:
                        new_str += '{' + a + '}' + b
    string = new_str
    return string

def fix_a_slash_b(string):
    if len(string.split('/')) != 2:
        return string
    a = string.split('/')[0]
    b = string.split('/')[1]
    try:
        a = int(a)
        b = int(b)
        assert string == '{}/{}'.format(a, b)
        new_string = '\\frac{' + str(a) + '}{' + str(b) + '}'
        return new_string
    except AssertionError:
        return string

def remove_right_units(string):
    # "\\text{ " only ever occurs (at least in the val set) when describing
    # units
    if '\\text{ ' in string:
        splits = string.split('\\text{ ')
        assert len(splits) == 2
        return splits[0]
    else:
        return string

def fix_sqrt(string):
    if '\\sqrt' not in string:
        return string
    splits = string.split('\\sqrt')
    new_string = splits[0]
    for split in splits[1:]:
        if split[0] != '{':
            a = split[0]
            new_substr = '\\sqrt{' + a + '}' + split[1:]
        else:
            new_substr = '\\sqrt' + split
        new_string += new_substr
    return new_string

def fix_sqrt_v2(string):
    _string = re.sub(r'\\sqrt(\w+)', r'\\sqrt{\1}', string)
    return _string

def strip_string(string):
    # linebreaks
    string = string.replace('\n', '')

    # remove inverse spaces
    string = string.replace('\\!', '')

    # replace \\ with \
    string = string.replace('\\\\', '\\')

    # replace tfrac and dfrac with frac
    string = string.replace('tfrac', 'frac')
    string = string.replace('dfrac', 'frac')

    # remove \left and \right
    string = string.replace('\\left', '')
    string = string.replace('\\right', '')

    # Remove circ (degrees)
    string = string.replace('^{\\circ}', '')
    string = string.replace('^\\circ', '')

    # remove dollar signs
    string = string.replace('\\$', '')

    # remove units (on the right)
    string = remove_right_units(string)

    # remove percentage
    string = string.replace('\\%', '')
    string = string.replace('\%', '')  # noqa: W605

    # " 0." equivalent to " ." and "{0." equivalent to "{." Alternatively,
    # add "0" if "." is the start of the string
    string = string.replace(' .', ' 0.')
    string = string.replace('{.', '{0.')
    # if empty, return empty string
    if len(string) == 0:
        return string
    if string[0] == '.':
        string = '0' + string

    # to consider: get rid of e.g. "k = " or "q = " at beginning
    if len(string.split('=')) == 2:
        if len(string.split('=')[0]) <= 2:
            string = string.split('=')[1]

    # fix sqrt3 --> sqrt{3}
    string = fix_sqrt(string)

    # remove spaces
    string = string.replace(' ', '')

    # \frac1b or \frac12 --> \frac{1}{b} and \frac{1}{2}, etc. Even works
    # with \frac1{72} (but not \frac{72}1). Also does a/b --> \\frac{a}{b}
    string = fix_fracs(string)

    # manually change 0.5 --> \frac{1}{2}
    if string == '0.5':
        string = '\\frac{1}{2}'

    # NOTE: X/Y changed to \frac{X}{Y} in dataset, but in simple cases fix
    # in case the model output is X/Y
    string = fix_a_slash_b(string)

    return string

def strip_string_v2(string):
    string = str(string).strip()
    # linebreaks
    string = string.replace('\n', '')

    # right "."
    string = string.rstrip('.')

    # remove inverse spaces
    string = string.replace('\\!', '')
    string = string.replace('\\ ', '')

    # replace \\ with \
    string = string.replace('\\\\', '\\')
    string = string.replace('\\\\', '\\')

    # replace tfrac and dfrac with frac
    string = string.replace('tfrac', 'frac')
    string = string.replace('dfrac', 'frac')

    # remove \left and \right
    string = string.replace('\\left', '')
    string = string.replace('\\right', '')

    # Remove unit: miles, dollars if after is not none
    _string = re.sub(r'\\text{.*?}$', '', string).strip()
    if _string != '' and _string != string:
        string = _string

    # Remove circ (degrees)
    string = string.replace('^{\\circ}', '')
    string = string.replace('^\\circ', '')

    # remove dollar signs
    string = string.replace('\\$', '')
    string = string.replace('$', '')

    string = string.replace('\\text', '')
    string = string.replace('x\\in', '')

    # remove percentage
    string = string.replace('\\%', '')
    string = string.replace('\%', '')  # noqa: W605
    string = string.replace('%', '')

    # " 0." equivalent to " ." and "{0." equivalent to "{." Alternatively,
    # add "0" if "." is the start of the string
    string = string.replace(' .', ' 0.')
    string = string.replace('{.', '{0.')

    # cdot
    string = string.replace('\\cdot', '')

    # inf
    string = string.replace('infinity', '\\infty')
    if '\\infty' not in string:
        string = string.replace('inf', '\\infty')
    string = string.replace('+\\inity', '\\infty')

    # and
    string = string.replace('and', '')
    string = string.replace('\\mathbf', '')

    # use regex to remove \mbox{...}
    string = re.sub(r'\\mbox{.*?}', '', string)

    # quote
    string.replace("'", '')
    string.replace('"', '')

    # i, j
    if 'j' in string and 'i' not in string:
        string = string.replace('j', 'i')

    # replace a.000b where b is not number or b is end, with ab, use regex
    string = re.sub(r'(\d+)\.0+([^\d])', r'\1\2', string)
    string = re.sub(r'(\d+)\.0+$', r'\1', string)

    # if empty, return empty string
    if len(string) == 0:
        return string
    if string[0] == '.':
        string = '0' + string

    # to consider: get rid of e.g. "k = " or "q = " at beginning
    if len(string.split('=')) == 2:
        if len(string.split('=')[0]) <= 2:
            string = string.split('=')[1]

    string = fix_sqrt_v2(string)
    string = string.replace(' ', '')

    # \frac1b or \frac12 --> \frac{1}{b} and \frac{1}{2}, etc.
    # Even works with \frac1{72} (but not \frac{72}1).
    # Also does a/b --> \\frac{a}{b}
    string = fix_fracs(string)

    # NOTE: X/Y changed to \frac{X}{Y} in dataset, but in simple
    # cases fix in case the model output is X/Y
    string = fix_a_slash_b(string)

    return string

def extract_content_from_brackets(text):
    # 使用正则表达式匹配括号中的内容
    pattern = r'[\(\（](.*?)[\)\）]'
    match = re.match(pattern, text)
    if match:
        return match.group(1)
    return text

def latex_fraction_to_decimal(latex_fraction):
    # 使用正则表达式匹配LaTeX格式的分数,转为小数
    match = re.search(r'\\frac\{(-?\d+)\}\{(\d+)\}', latex_fraction)
    if match:
        numerator = int(match.group(1))
        denominator = int(match.group(2))
        if latex_fraction.startswith("-"):
            return -numerator / denominator
        else:
            return numerator / denominator

    return latex_fraction

def convert_latex_fraction(latex_string):
    # 定义正则表达式来匹配LaTeX分数，去掉大括号
    fraction_pattern = re.compile(r'\\frac{(\d+)}{(\d+)}')

    # 使用正则表达式替换LaTeX分数为普通分数格式
    non_latex_string = fraction_pattern.sub(r'\1/\2', latex_string)

    return non_latex_string

def remove_single_i_or_pi(expression):
    # 检查字符串中是否有且仅有一个 `\pi`
    pi_count = expression.count(r'\pi')
    i_count = expression.count('i')
    # 移除唯一的 `\pi`
    if pi_count == 1 and i_count == 1:
        expression = expression.replace(r'\pi', '').strip(" ")+'\\pi'
    # 移除唯一的 `i`
    elif i_count == 1 and  pi_count == 0:
        expression = expression.replace('i', '')+'i'

    return expression

def is_equiv(str1, str2,version='v2', verbose=False):
    if str1 is None and str2 is None:
        print('WARNING: Both None')
        return True
    if str1 is None or str2 is None:
        print(str1,str2)
        return False

    if version == 'v1':
        strip_string_func = strip_string
    elif version == 'v2':
        strip_string_func = strip_string_v2
    else:
        raise NotImplementedError

    try:
        ss1 = strip_string_func(str1)
        ss2 = strip_string_func(str2)
        if verbose:
            print(ss1, ss2)
        if ss1 == ss2:
            return True
        ss1 = normalize_final_answer(ss1)
        ss2 = normalize_final_answer(ss2)
        if ss1 == ss2:
            return True
    except Exception:
        pass

    try:
        ss1 = normalize_final_answer(str1)
        ss2 = normalize_final_answer(str2)
        if ss1 == ss2:
            return True
        if abs(float(ss1) - float(ss2))<1e-10:
            return True

    except Exception:
        pass

    try:

        ss1 = normalize_final_answer(str1)
        ss2 = normalize_final_answer(str2)

        #(P)-> P
        ss2 = extract_content_from_brackets(ss2)
        if ss1 == ss2:
            return True

        #\\frac{11}{2} -> 5.5
        ss2 = latex_fraction_to_decimal(ss2)
        try:
            if abs(float(ss1) - float(ss2))<1e-10:
                # print("x1-2 ", ss1, "\t||\t", ss2)
                return True
        except:
            pass
        ss1 = convert_latex_fraction(ss1)
        if ss1 == ss2:
            # print("x2 ", ss1, "\t||\t", ss2)
            return True
        ss2 = ss2.strip("\,")
        if ss1 == ss2:
            # print("x3 ", ss1, "\t||\t", ss2)
            return True
        tmp=ss1
        ss1 = remove_single_i_or_pi(ss1)
        if "{2}" in ss1 and 'pi' in ss1:
            print(tmp, ss1)
        if ss1 == ss2:
            print("x4 ", ss1, "\t||\t", ss2)
            return True
    except Exception:
        pass

    return str1 == str2

def last_boxed_only_string(string):
    idx = string.rfind('\\boxed')
    if idx < 0:
        idx = string.rfind('\\fbox')
        if idx < 0:
            return None

    i = idx
    right_brace_idx = None
    num_left_braces_open = 0
    while i < len(string):
        if string[i] == '{':
            num_left_braces_open += 1
        if string[i] == '}':
            num_left_braces_open -= 1
            if num_left_braces_open == 0:
                right_brace_idx = i
                break
        i += 1

    if right_brace_idx is None:
        retval = None
    else:
        retval = string[idx:right_brace_idx + 1]

    return retval


def remove_boxed(s):
    left = '\\boxed{'
    try:
        assert s[:len(left)] == left
        assert s[-1] == '}'
        return s[len(left):-1]
    except Exception:
        return None


def extract_boxed_answer(pred_str, strip_double_curly_brace=False):
    boxed_str = last_boxed_only_string(pred_str)
    if boxed_str is None:
        return None
    answer = remove_boxed(boxed_str)
    if answer is None:
        return None
    if strip_double_curly_brace:
        match = re.match('^\{(.*)\}$', answer)  # noqa: W605
        if match:
            answer = match.group(1)
    return answer


def normalize_final_answer(final_answer: str) -> str:
    """Normalize a final answer to a quantitative reasoning question."""
    # final_answer = final_answer.split('=')[-1]
    SUBSTITUTIONS = [('an ', ''), ('a ', ''), ('.$', '$'), ('\\$', ''),
                     (r'\ ', ''), (' ', ''), ('mbox', 'text'),
                     (',\\text{and}', ','), ('\\text{and}', ','),
                     ('\\text{m}', '\\text{}'), ('\\le', '<')]
    REMOVED_EXPRESSIONS = [
        'square', 'ways', 'integers', 'dollars', 'mph', 'inches', 'ft',
        'hours', 'km', 'units', '\\ldots', 'sue', 'points', 'feet', 'minutes',
        'digits', 'cents', 'degrees', 'cm', 'gm', 'pounds', 'meters', 'meals',
        'edges', 'students', 'childrentickets', 'multiples', '\\text{s}',
        '\\text{.}', '\\text{\ns}', '\\text{}^2', '\\text{}^3', '\\text{\n}',
        '\\text{}', r'\mathrm{th}', r'^\circ', r'^{\circ}', r'\;', r',\!',
        '{,}', '"', '\\dots', '\n', '\r', '\f'
    ]
    for before, after in SUBSTITUTIONS:
        final_answer = final_answer.replace(before, after)
    for expr in REMOVED_EXPRESSIONS:
        final_answer = final_answer.replace(expr, '')

    # Extract answer that is in LaTeX math, is bold,
    # is surrounded by a box, etc.
    final_answer = re.sub(r'(\\text\{)(.*?)(\})', '\\2', final_answer)
    final_answer = re.sub(r'(\\textbf\{)(.*?)(\})', '\\2', final_answer)
    final_answer = re.sub(r'(\\overline\{)(.*?)(\})', '\\2', final_answer)
    final_answer = re.sub(r'(\\boxed\{)(.*)(\})', '\\2', final_answer)
    assert '\n' not in final_answer
    assert '\r' not in final_answer
    assert '\f' not in final_answer
    if len(re.findall(r'finalansweris(.*)', final_answer)) > 0:
        final_answer = re.findall(r'finalansweris(.*)', final_answer)[-1]

    if len(re.findall(r'answer?is:?(.*)', final_answer)) > 0:
        final_answer = re.findall(r'answer?is:?(.*)', final_answer)[-1]

    if len(re.findall(r'oxed\{(.*?)\}', final_answer)) > 0:
        final_answer = re.findall(r'oxed\{(.*?)\}', final_answer)[-1]

    if len(re.findall(r'\$(.*?)\$', final_answer)) > 0:
        final_answer = re.findall(r'\$(.*?)\$', final_answer)[-1]
    final_answer = final_answer.strip()
    if 'rac' in final_answer and '\\frac' not in final_answer:
        final_answer = final_answer.replace('rac', '\\frac')

    final_answer = re.sub(r'(frac)([^{])(.)', 'frac{\\2}{\\3}', final_answer)
    final_answer = re.sub(r'(sqrt)([^{])', 'sqrt{\\2}', final_answer)
    final_answer = final_answer.replace('$', '')

    # Normalize 100,000 -> 100000
    if final_answer.replace(',', '').isdigit():
        final_answer = final_answer.replace(',', '')

    return final_answer



def math_postprocess_v2(text: str) -> str:

    cand_ans = extract_boxed_answer(text, strip_double_curly_brace=True)
    if cand_ans:
        return cand_ans
    for maybe_ans in text.split('.'):
        if re.search('final answer|answer is', maybe_ans.lower()):
            return normalize_final_answer(maybe_ans)
    return normalize_final_answer(text.split('.')[0])


def extract_text(input_string):
    # 使用正则表达式匹配 \text{内容} 模式
    pattern = r'\\text\{([^}]*)\}'
    match = re.search(pattern, input_string)
    
    if match:
        # 如果匹配到，返回匹配的内容
        return match.group(1)
    else:
        # 如果没有匹配到，返回原始字符串
        return input_string

def judge_pred_res(pred,refer):
    pred = math_postprocess_v2(pred)
    if is_equiv(pred, refer,version='v2') or math_equal(pred,refer):
        return True,pred
    else:
        return False,pred


if __name__=="__main__":
    fn=open("math-test-err-qa.json",'w')
    fn1=open("math-test-right-qa.jsonl",'w')
    res_dir=sys.argv[1]
    total_right=0
    total_err=0
    miss=0

    source_infos={}
    with open("/mnt/share/weihuaqiang/data/math-test5k_source_infos.jsonl") as f:
    #with open("../math-test5k_source_infos.jsonl") as f:
        for line in f.readlines():
            info=json.loads(line)
            source_infos.update({info["question"]:info["type"]})

    right_types={}
    err_types = {}
    for r in os.listdir(res_dir):
        if r.startswith("math_") and r.endswith(".json"):
            res = os.path.join(res_dir,r)
            # print(r)
            right=0
            err=0
            with open(res) as f:
                data=json.load(f)
                for key,value in data.items():
                    # print(key)
                    question=value["origin_prompt"][-1]["prompt"].replace("<|im_start|>user\n",'').replace("<|im_end|>\n",'').replace("\nPlease reason step by step, and put your final answer within \\boxed{}.",'')
                    prediction=value["prediction"]
                    gold=value["gold"]
                    type=source_infos[question]
                    try:
                        j, pred = judge_pred_res(prediction,gold)
                        if j:
                            right+=1
                            save_info={
                                "question": question,
                                "gold": gold,
                                "prediction": prediction
                            }
                            fn1.write(json.dumps(save_info,ensure_ascii=False)+'\n')
                            if type in right_types:
                                base = right_types[type]
                                right_types[type] = base + 1
                            else:
                                right_types[type] = 1
                        else:
                            err+=1
                            # print("###########err: \n")
                            # print("prediction:",prediction)
                            # print("pred: ",pred)
                            # print("gold: ", gold)

                            if type in err_types:
                                base = err_types[type]
                                err_types[type] = base + 1
                            else:
                                err_types[type] = 1
                            save_info={
                                "type": type,
                                "question": question,
                                "gold": gold,
                                "prediction": prediction
                            }
                            if type=='Intermediate Algebra':
                               fn.write(json.dumps(save_info,ensure_ascii=False)+'\n')
                    except:
                        miss+=1
                        continue
            # print(f"right: {right}, err:{err},miss: {miss}")
            total_right+=right
            total_err+=err
    print(f"total_right: {total_right}, total_err:{total_err},excep: {miss}")
    print("right_types:")
    print(right_types)
    print("err_types:")
    print(err_types)
    # 计算总正确率
    accuracy = total_right / (total_right + total_err) * 100
    
    # 构造总览表格数据
    summary_table = [
        ["Total Right", total_right],
        ["Total Error", total_err],
        ["Exception", miss],
        ["Accuracy", f"{accuracy:.2f}%"]
    ]
    
    # 构造类型表格数据，包括每种类型的正确率
    types_table = [["Type", "Right Count", "Error Count", "Accuracy"]]
    for key in right_types.keys():
        right_count = right_types[key]
        err_count = err_types.get(key, 0)
        type_accuracy = right_count / (right_count + err_count) * 100 if (right_count + err_count) > 0 else 0
        types_table.append([key, right_count, err_count, f"{type_accuracy:.2f}%"])
    
    # 打印总览表格
    print(tabulate(summary_table, headers=["Metric", "Value"], tablefmt="grid"))
    
    # 打印类型表格
    print("\nTypes Count:")
    print(tabulate(types_table, headers="firstrow", tablefmt="grid"))
