import os
import requests
import json
import sys
from functools import partial
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
from judge_math import math_postprocess_v2,is_equiv
import re
def read_json(path):
    res = []
    with open(path) as f:
        for line in f:
            kptinfo = json.loads(line)
               
            #res.append(convert_one2qa(kptinfo))
            res.append(kptinfo)
    return res

def convert_one2qa(info):
    conversation = info["conversation"][0]
    input = conversation["input"]
    output = conversation["output"]

    tmp = input[input.find("<|im_start|>user\n") + len("<|im_start|>user\n"):]
    user_content = tmp[:tmp.find("<|im_end|>\n")]
    ans = output[:output.find("<|im_end|>")]

    data = {
        "question": user_content,
        "answer": ans
    }
    return data


def write_json(res, path):
    with open(path, 'w') as f:
        for line in res:
            f.write(json.dumps(line, ensure_ascii=False) + '\n')

internlm2_chat_sys=dict(
        SYSTEM='<|im_start|>system\n{system}<|im_end|>\n',
        INSTRUCTION=('<|im_start|>user\n{input}<|im_end|>\n'
                     '<|im_start|>assistant\n'),
        SUFFIX='<|im_end|>',
        SUFFIX_AS_EOS=True,
        SEP='\n',
        STOP_WORDS=['<|im_end|>'])

def gsm8k_postprocess(text: str) -> str:
    #text = text.split('Question:')[0]
    numbers = re.findall(r'\-?\d+\.\d+|\-?\d+', text)
    if not numbers:
        return 'NULL'
    return numbers[-1]

def extract_dollar_expressions(text):

    # 使用正则表达式提取数学表达式
    matches = re.findall(r'\$(.*?)\$', text)
    if matches:
        return matches[-1]
    else:
        return text

def get_gold(info):
    hints = info["hints"]
    gt=hints[-1]
    results=[]
    res = extract_dollar_expressions(gt)
    results.append(res)
    res = gsm8k_postprocess(gt)
    results.append(res)
    return results
    


def single_turn(info,save_path,err_path):
    question=info["question"]
    #question=info["problem"]
    #input = f"User: {question}\nPlease reason step by step, and put your final answer within " + "\\boxed{}"+"\nAssistant:"
    input = f"{question}\nPlease reason step by step, and put your final answer within " + "\\boxed{}."+"\n"
    #input = f"{question}\n请通过逐步推理来解答问题，并把最终答案放置于" + "\\boxed{}中。"+"\n"
    #input = info #f"User: {info},请直接给出答案."+"\nAssistant:"
    #input = f"{question}"
    #system_prompt = "请直接给出答案."
    system_prompt = ""
    #input_format = internlm2_chat_sys['SYSTEM'].format(system=system_prompt) +  internlm2_chat_sys['INSTRUCTION'].format(input=input)
    input_format = internlm2_chat_sys['INSTRUCTION'].format(input=input)
    data = {
        'inputs':  input_format,
        "parameters": {
            'do_sample': False,
            'ignore_eos': False,
            'temperature': 1.0,
            'top_p': 0.7,
            'repetition_penalty': 1.0,
            #'stop_sequences': '<｜end▁of▁sentence｜>',
            'stop_sequences': '<|im_end|>',
            'max_new_tokens': 4096,
            }
        }
    #max_try=10
    i=1
    while i>0:
        #try:
            response = requests.post(url, headers=headers, data=json.dumps(data))
            output = {'question': question}
            pred = response.json()["generated_text"][0]
            ans = pred[:pred.find("<|im_end|>")]
            output["model_predict"] = ans
            output["source_info"]=info
            pred = math_postprocess_v2(ans)
            #golds = get_gold(info)
            #output["golds"]=golds
            gold=info["gold"]
            #for gold in golds:
            if is_equiv(pred, str(gold), version='v2'):
                with open(save_path,'a+') as fw:
                    fw.write(json.dumps(info,ensure_ascii=False)+'\n')
                    #print(f"pred: {pred}, gold: {gold}, right",flush=True)
                    fw.flush()
                    i-=1
                    return output
            with open(err_path,'a+') as fw:
                fw.write(json.dumps(output,ensure_ascii=False)+'\n')
                #print(f"pred: {pred}, golds: {golds}, err",flush=True)
                fw.flush()
                i-=1
                continue
                
            #if not is_equiv(pred, refer, version='v2'):
            #    with open(err_path,'a+') as fw:
            #        fw.write(json.dumps(output,ensure_ascii=False)+'\n')
            #        break
            #else:
            #    with open(save_path,'a+') as fw:
            #        fw.write(json.dumps(info,ensure_ascii=False)+'\n')
            #        i-=1
            #        continue
                
            return output
        #except:
            #print("err format!")
            #with open(err_path,'a+') as fw:
            #    fw.write(json.dumps(info,ensure_ascii=False)+'\n')
            #return None
        #    print("err",flush=True)
        #    i-=1
        #    continue


if __name__ == '__main__':
    ip="0.0.0.0"
    #port="8084"
    port='8080'
    url = f'http://{ip}:{port}/generate'
    headers = {'Content-Type': 'application/json'}

    #input_content = """点$$(-7,m)$$和点$$(-8,n)$$都在直线$$y=-2x-6$$上，则$$m$$和$$n$$>> 大小关系是（~ ）"""
    #input_content = """3 个菠萝的重量等于2 个西瓜的重量，3 个西瓜的重量等于4 个榴莲的重量，那么9 个菠萝的重量等于多少个榴莲的重量？"""
 
    #print(single_turn(input_content))
    # import sys; sys.exit(0)

    #jsonl_path = sys.argv[1]
    #jsonl_path = '/mnt/afs_1/weihuaqiang/data/L4.15/gts/mnt/share/weihuaqiang/data/gsm8k-math-ori-hb/math_train_7500_qa_deepseekgen-0327-sft_7500_20240327.jsonl'
    #jsonl_path=sys.argv[1]
    #jsonl_path='/mnt/share/weihuaqiang/datasets/test/MATH-Hard-CN-test.jsonl'
    jsonl_path='/mnt/share/weihuaqiang/datasets/test/Math-Hard-test-EN-all.jsonl'
    model_v=str(sys.argv[1])
    save_dir=f'/mnt/share/weihuaqiang/workdir/output/math-hard-en/'+model_v
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    #start=0
    #end=100000
    #jsonl_path='/mnt/afs_1/weihuaqiang/to_1424/test/opencompass/jobs/wei_math/infer/data/L4.65-sel/right-golds/L4.65-cn-gold-sel-0-7.jsonl'
    #jsonl_path='/mnt/afs_1/weihuaqiang/to_1424/test/opencompass/jobs/wei_math/infer/data/L4.65-sel/right-golds/L4.65-en-gold-sel-0-7.jsonl'
    #jsonl_path='/mnt/afs_1/weihuaqiang/to_1424/test/opencompass/jobs/wei_math/infer/data/L4.65-sel/right-golds/L4.65-en-meta-gold-sel-0-40.jsonl'
    infos = read_json(jsonl_path)
    save_path1 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_v}-right.jsonl"))
    save_path2 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_v}-err.jsonl"))
    print(save_path1)
    #single_turn(infos[0])
    res = []
    total=len(infos)
    parallel = 800
    #if total>8000:
    #    parallel = 800
    #else:
    #    parallel = total//10
    single_turn_with_path = partial(single_turn, save_path=save_path1,err_path=save_path2)
    with ThreadPoolExecutor(max_workers=parallel) as executor:
        for output in tqdm(
                executor.map(single_turn_with_path, infos),
                total=len(infos),
                smoothing=0.1):
            pass
            #res.append(output)
    #write_json(res, save_path1)
