import os
import re
import json
from tqdm import tqdm
import sys
from tabulate import tabulate
import regex
from math import isclose
from sympy import simplify, N
from sympy.parsing.sympy_parser import parse_expr
from sympy.parsing.latex import parse_latex
from latex2sympy2 import latex2sympy

# 提取pred中最后一个ABCDE，然后作为答案
# TODO：这个是否合理呢？
# 思考: 其实在一定程度上是合理的，因为答案一般只有第一个字母是大写的，那么取最后一个一定程度上可以避免选取到第一个字母而选择到预测出来的选项（如果有的话）。
def choice_answer_clean(pred: str):
    pred = pred.strip("\n").rstrip(".").rstrip("/").strip(" ").lstrip(":")
    # Clean the answer based on the dataset
    tmp = re.findall(r"\b(A|B|C|D|E)\b", pred.upper())
    if tmp:
        pred = tmp
    else:
        pred = [pred.strip().strip(".")]
    pred = pred[-1]
    # Remove the period at the end, again!
    pred = pred.rstrip(".").rstrip("/")
    return pred

def parse_digits(num):
    num = regex.sub(",", "", str(num))
    try:
        return float(num)
    except:
        if num.endswith("%"):
            num = num[:-1]
            if num.endswith("\\"):
                num = num[:-1]
            try:
                return float(num) / 100
            except:
                pass
    return None

def is_digit(num):
    # paired with parse_digits
    return parse_digits(num) is not None

def numeric_equal(prediction: float, reference: float):
    # 这里的Tolerance很影响结果，例如：
    # 33.3 和100 / 3 在当前的tolerance下不相等，但是在1e-1下相等
    return isclose(reference, prediction, rel_tol=1e-4) 

def str_to_pmatrix(input_str):
    # 从输入字符串中提取矩阵，并将其格式化为 LaTeX pmatrix 的表示形式
    input_str = input_str.strip()
    matrix_str = re.findall(r"\{.*,.*\}", input_str)
    pmatrix_list = []

    for m in matrix_str:
        m = m.strip("{}")
        pmatrix = r"\begin{pmatrix}" + m.replace(",", "\\") + r"\end{pmatrix}"
        pmatrix_list.append(pmatrix)

    return ", ".join(pmatrix_list)

def symbolic_equal(a, b):
    def _parse(s):
        for f in [parse_latex, parse_expr, latex2sympy]:
            try:
                return f(s.replace("\\\\", "\\"))
            except:
                try:
                    return f(s)
                except:
                    pass
        return s

    # 对a和b的表达式使用工具[parse_latex, parse_expr, latex2sympy]进行解析
    a = _parse(a)
    b = _parse(b)

    # 1. 直接相等的情况
    try:
        if str(a) == str(b) or a == b:
            return True
    except:
        pass

    # 2. 比较两个符号是否等价，例子如下：
    # a: x+1, b: 1+x ---> a.equals(b) is True
    # simplify((x**2 + x)/(x*sin(y)**2 + x*cos(y)**2)) == x + 1
    try:
        if a.equals(b) or simplify(a - b) == 0:
            return True
    except:
        pass

    # 3. 方程等价比较，例子如下：
    # a: "x + 1 = y"，b: "y = x + 1"，返回True
    try:
        if (abs(a.lhs - a.rhs)).equals(abs(b.lhs - b.rhs)):
            return True
    except:
        pass

    try:
        if numeric_equal(float(N(a)), float(N(b))):
            return True
    except:
        pass

    # 4. 矩阵相等的情况
    try:
        # if a and b are matrix
        if a.shape == b.shape:
            _a = a.applyfunc(lambda x: round(x, 3))
            _b = b.applyfunc(lambda x: round(x, 3))
            if _a.equals(_b):
                return True
    except:
        pass

    return False

def math_equal(prediction, reference, verbose=False):

    # 先返回最明显的情况，也就是None的情况
    if prediction is None and reference is None:
        return True
    
    if prediction is None or reference is None:
        return False
    
    # 当prediction和Reference都不是None的时候如下：
    try:
        if str(prediction.strip().lower()) == str(reference.strip().lower()):
            return True
    except:
        pass
    # 提取选项和GT的选项对比。 TODO： 检查合理性
    if (reference in ["A", "B", "C", "D", "E"] and choice_answer_clean(prediction) == reference):
        return True
    
    # --------------------------- 1. Numerical equal ---------------------------
    # 如果prediction和reference都是数值，检验是否相等
    try:
        if is_digit(prediction) and is_digit(reference):
            prediction = parse_digits(prediction)
            reference = parse_digits(reference)
            try:
                if numeric_equal(prediction, reference):
                    return True 
            except Exception:
                pass

            return False
    except:
        pass
    
    # 如果prediction是 None、空字符串、空列表，那么则会返回False
    if not prediction and prediction not in [0, False]:
        return False

    # --------------------------- 2. Symbolic equal ---------------------------
    # 转换为字符串，并且删除字符串开头和结尾的空白。
    reference = str(reference).strip()
    prediction = str(prediction).strip()

    # 如果prediction是latex形式的矩阵，那么统一一下reference和prediction
    if "pmatrix" in prediction and not "pmatrix" in reference:
        reference = str_to_pmatrix(reference)

    # 2.1.1：意思就是prediction有[]和()括号，但是reference没有，就去除这个冗余的括号
    pred_str, ref_str = prediction, reference
    if (prediction.startswith("[") and prediction.endswith("]") and not reference.startswith("(")) or (
        prediction.startswith("(") and prediction.endswith(")") and not reference.startswith("[")):

        pred_str = pred_str.strip("[]()")
        ref_str = ref_str.strip("[]()")

    # 2.1.2：去除所有的括号，如果相等，就return True
    for s in ["{", "}", "(", ")"]:
        ref_str = ref_str.replace(s, "")
        pred_str = pred_str.replace(s, "")
    if pred_str.lower() == ref_str.lower():
        return True
    
    # 2.2 查看prediction和reference是否都是括号或方括号包围的字符串
    # 例如 [a, b] 和 [c, d] ---> list(a, b) 和 list(c, d)  ---> if a == c and b == d, return True
    if (
        regex.match(r"(\(|\[).+(\)|\])", prediction) is not None
        and regex.match(r"(\(|\[).+(\)|\])", reference) is not None
    ):
        pred_parts = prediction[1:-1].split(",")
        ref_parts = reference[1:-1].split(",")
        if len(pred_parts) == len(ref_parts):
            if all(
                [
                    math_equal(pred_parts[i], ref_parts[i])
                    for i in range(len(pred_parts))
                ]
            ):
                return True
    # 2.3 如果prediction和reference都是矩阵，那么逐行逐个比较矩阵的元素，返回比较的结果           
    if (
        (
            prediction.startswith("\\begin{pmatrix}")
            or prediction.startswith("\\begin{bmatrix}")
        )
        and (
            prediction.endswith("\\end{pmatrix}")
            or prediction.endswith("\\end{bmatrix}")
        )
        and (
            reference.startswith("\\begin{pmatrix}")
            or reference.startswith("\\begin{bmatrix}")
        )
        and (
            reference.endswith("\\end{pmatrix}") 
            or reference.endswith("\\end{bmatrix}")
        )
    ):
        pred_lines = [
            line.strip()
            for line in prediction[
                len("\\begin{pmatrix}") : -len("\\end{pmatrix}")
            ].split("\\\\")
            if line.strip()
        ]
        ref_lines = [
            line.strip()
            for line in reference[
                len("\\begin{pmatrix}") : -len("\\end{pmatrix}")
            ].split("\\\\")
            if line.strip()
        ]
        matched = True
        if len(pred_lines) == len(ref_lines):
            for pred_line, ref_line in zip(pred_lines, ref_lines):
                pred_parts = pred_line.split("&")
                ref_parts = ref_line.split("&")
                if len(pred_parts) == len(ref_parts):
                    if not all(
                        [
                            math_equal(
                                pred_parts[i],
                                ref_parts[i],
                            )
                            for i in range(len(pred_parts))
                        ]
                    ):
                        matched = False
                        break
                else:
                    matched = False

                if not matched:
                    break
        else:
            matched = False

        if matched:
            return True
    # 2.4 处理有等号的情况
    # 如果prediction和reference都有等号，把所有的信息放到一边，然后进行比较   
    if prediction.count("=") == 1 and reference.count("=") == 1:
        pred = prediction.split("=")
        pred = f"{pred[0].strip()} - ({pred[1].strip()})"
        ref = reference.split("=")
        ref = f"{ref[0].strip()} - ({ref[1].strip()})"
        # TODO：这个加负号是否合理呢？
        if symbolic_equal(pred, ref) or symbolic_equal(f"-({pred})", ref):
            return True
        
    # 如果prediction有一个等号，且左边是一个很简单的表达式，然后reference没有等号， 那么直接比较prediction的右边和reference。
    # 例如 prediction: x = 5, reference: 5 ---> True
    elif (prediction.count("=") == 1 and len(prediction.split("=")[0].strip()) <= 2 and "=" not in reference):
        if math_equal(prediction.split("=")[1], reference):
            return True
    # 和上面的情况类似，只不过prediction和reference的角色相反。
    elif (reference.count("=") == 1 and len(reference.split("=")[0].strip()) <= 2 and "=" not in prediction):
        if math_equal(prediction, reference.split("=")[1]):
            return True
        
    # 2.5 查看这个str是不是symbolic_equal
    if symbolic_equal(prediction, reference):
            return True
    
    # 如果所有条件都不满足，最终return False
    return False

def _test_math_equal():
    pred, gold = "0.0833333333333333", "\\frac{1}{12}"
    # pred, gold = "(1,4.5)", "(1,\\frac{9}{2})"
    # pred, gold = "\\frac{x}{7}+\\frac{2}{7}", "\\frac{x+2}{7}"
    # pred, gold = "\\sec^2(y)", "\\tan^2(y)+1"
    # pred, gold = "\\begin{pmatrix}-\\frac{7}{4}&-2\\\\4&\\frac{1}{4}\\end{pmatrix}", "(\\begin{pmatrix}-\\frac{7}{4}&-2\\\\4&\\frac{1}{4}\\\\\\end{pmatrix})"
    
    # pred = '\\begin{pmatrix}\\frac{1}{3x^{2/3}}&0&0\\\\0&1&0\\\\-\\sin(x)&0&0\\end{pmatrix}'
    # gold = '(\\begin{pmatrix}\\frac{1}{3\\sqrt[3]{x}^2}&0&0\\\\0&1&0\\\\-\\sin(x)&0&0\\\\\\end{pmatrix})'

    # pred= '-\\frac{8x^2}{9(x^2-2)^{5/3}}+\\frac{2}{3(x^2-2)^{2/3}}'
    # gold= '-\\frac{2(x^2+6)}{9(x^2-2)\\sqrt[3]{x^2-2}^2}'

    # pred =  '-34x-45y+20z-100=0'
    # gold = '34x+45y-20z+100=0'

    # pred = '\\frac{100}{3}'
    # gold = '33.3'

    # pred = '\\begin{pmatrix}0.290243531202435\\\\0.196008371385084\\\\-0.186381278538813\\end{pmatrix}'
    # gold = '(\\begin{pmatrix}0.29\\\\0.196\\\\-0.186\\\\\\end{pmatrix})'

    # pred = '\\frac{\\sqrt{\\sqrt{11}+\\sqrt{194}}}{2\\sqrt{33}+15}'
    # gold = '\\frac{\\sqrt{\\sqrt{11}+\\sqrt{194}}}{15+2\\sqrt{33}}'

    # pred = '(+5)(b+2)'
    # gold = '(a+5)(b+2)'

    # pred = '\\frac{1+\\sqrt{5}}{2}'
    # gold = '2'

    # pred = '\\frac{34}{16}+\\frac{\\sqrt{1358}}{16}'
    # gold = '4'

    # pred = '1'
    # gold = '1\\\\sqrt{19}'

    # pred = "(0.6,2.6667]"
    # gold = "(\\frac{3}{5},\\frac{8}{3}]"

    result = math_equal(pred, gold)
    return pred, gold, result


if __name__ == "__main__":
    pred, gold, result = _test_math_equal()
    print("The pred: ", pred)
    print("The gold: ", gold)
    print("pred is equal to gold: ", math_equal(pred, gold))
    