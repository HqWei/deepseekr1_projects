from openai import OpenAI
import json

def get_deepseek_r1(question,API_KEY='sk-ea80f48ddb024c0eb7a237bf2a3d9bc2'):
   # API_KEY = 'sk-fea581eea5d040c8a6439f3c916bbe1a' #wei personal
   # API_KEY = 'sk-ea80f48ddb024c0eb7a237bf2a3d9bc2' # duomo
   # APE_KEY = 'sk-111b65f3c2844d07b2166487ee4cf5f7' #senseGOGOGO
   client = OpenAI(api_key=API_KEY, base_url="https://api.deepseek.com")

   # Round 1
   messages = [{"role": "user", "content": question}]
   response = client.chat.completions.create(
      model="deepseek-reasoner",
      messages=messages,
      # stream=True
   )

   reasoning_content = response.choices[0].message.reasoning_content
   content = response.choices[0].message.content
   completion_tokens = json.loads(response.json())["usage"]["completion_tokens"]
   finish_reason = response.choices[0].finish_reason

   return reasoning_content,content,completion_tokens,finish_reason


def demo(question):
   API_KEY ='sk-ea80f48ddb024c0eb7a237bf2a3d9bc2'
   client = OpenAI(api_key=API_KEY, base_url="https://api.deepseek.com")

   # Round 1
   messages = [{"role": "user", "content":question}]
   response = client.chat.completions.create(
      model="deepseek-reasoner",
      messages=messages,
      # stream=True
   )

   reasoning_content = response.choices[0].message.reasoning_content
   content = response.choices[0].message.content
   completion_tokens = json.loads(response.json())["usage"]["completion_tokens"]
   finish_reason = response.choices[0].finish_reason
   import pdb;pdb.set_trace()
   print("Think: ")
   print(reasoning_content)
   print("Answer:")
   print(content)
   print("Token:")
   print(completion_tokens)
   # Round 2
   # messages.append({'role': 'assistant', 'content': content})
   # messages.append({'role': 'user', 'content': "How many Rs are there in the word 'strawberry'?"})
   # response = client.chat.completions.create(
   #    model="deepseek-reasoner",
   #    messages=messages
   # )

   # print(content)
if __name__=="__main__":
   question= "9.11 and 9.8, which is greater?"
   demo(question)