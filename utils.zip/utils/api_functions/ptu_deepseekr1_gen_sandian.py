import os
import requests
import json
import sys
from functools import partial
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
# from math_judge.judge_math import math_postprocess_v2,is_equiv
# from math_judge.grader import math_equal
import re
import time
import openai
from time import sleep
import openai_proxy


def extract_reasoning_and_answer(text):
    # 使用正则表达式提取 <think> 和 </think> 标签之间的内容
    reasoning_pattern = r'<think>(.*?)</think>'
    match = re.search(reasoning_pattern, text, re.DOTALL)  # re.DOTALL 使得 . 可以匹配换行符

    if match:
        # 提取 <think> 和 </think> 之间的内容
        reasoning_content = match.group(1).strip()

        # 提取 </think> 之后的内容
        after_think_content = text[match.end():].strip()

        # 如果 </think> 后的内容非空，则提取为 answer_content
        if after_think_content:
            answer_content = after_think_content
            return reasoning_content, answer_content
        else:
            return reasoning_content, None
    else:
        # 如果没有找到 <think> 标签，返回 None
        return None, None

def get_R1_response(info, max_try=2):
    question = info["question"]
    prompt = f"{question}"
    # print(prompt)
    my_key = "896076fe1c1252a009718333579c2a6f"
    client = openai_proxy.GptProxy(api_key=my_key)
    rsp = client.generate(
        messages=[{"role": "user", "content": prompt}],
        model="DeepSeek-R1",  # model="DeepSeek-R1", model="Doubao-1.5-pro-32k""DeepSeek-V3"
        channel_code="doubao",  # 使用豆包必须设定此项
        transaction_id=f"bbeh",  # 一个唯一的标识符, 每个子账户的每个模型的每个transaction_id都必须唯一
    )
    for i in range(max_try):
        try:
            if rsp.ok:
                response = rsp.json()
                if "data" not in response:
                    print(response)
                    sleep(3.0)
                    continue
                finish_reason = response["data"]["response_content"]["choices"][0]["finish_reason"]
                solution = response["data"]["response_content"]["choices"][0]["message"]["content"]
                reasoning_content = response["data"]["response_content"]["choices"][0]["message"]["reasoning_content"]
                print("="*100)
                print(question)
                print("-"*50)
                print(solution)
                return reasoning_content,solution,finish_reason
            else:
                print(rsp.text)
                continue
        except Exception as e:
            print(f"Error: {e}")
            continue


    return False,False,False


def read_json(path):
    res = []
    with open(path) as f:
        for line in f:
            kptinfo = json.loads(line)
               
            #res.append(convert_one2qa(kptinfo))
            res.append(kptinfo)
    return res


def single_turn(info,save_path,err_path, miss_path):
    q=info["question"]
    messages=[{
        "role": "user",
        "content": q
    }]
    i=10

    while i>0:
        try:
            # response = R1_caller(messages)
            reasoning_content,solution,finish_reason = get_R1_response(info)
            if finish_reason!='stop':
                print("Err response!!")
                i -= 1
                continue
            print("="*100)
            if not reasoning_content or not solution:
                print("Err format!!")
                i -= 1
                continue
            output = {
                "type": info["type"],
                "subtype": info["subtype"],
                "question": info["question"],
                'ref_answer': info["answer"],
                'reasoning_content': reasoning_content,
                'answer_content': solution
            }
            with open(save_path,'a+') as fw:
                fw.write(json.dumps(output,ensure_ascii=False)+'\n')
                print(f"Success: ", info["subtype"], flush=True)
                fw.flush()
                return 1


        except Exception as e:

            print(f"Error: {e}")
            i -= 1
            sleep(1.0)
            continue
    with open(miss_path,'a+') as fw:
        fw.write(json.dumps(info,ensure_ascii=False)+'\n')
        print("miss. ")
        fw.flush()
        i-=1



                

def get_left(infos,save_paths):
    used=set()
    valid_infos=[]
    for save_path in save_paths:
        if not os.path.exists(save_path):
            continue
        with open(save_path) as f:

            for line in f.readlines():
                info=json.loads(line)
                used.add(info["question"])
    for info in infos:
        if info["question"] in used:
            continue
        valid_infos.append(info)
    return valid_infos




if __name__ == '__main__':


    jsonl_path='/data/data/fangxie/sandian-test/sandian-test/fenke/sandian-test-subject-fenke.jsonl'
    model_name='deepseek_r1'
    dataset_name='sandian-test'
    save_dir=f'/data/data/fangxie/sandian-test/deepseekr1_gen_answer/{dataset_name}'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    infos = read_json(jsonl_path)
    save_path1 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_name}-right.jsonl"))
    save_path2 = os.path.join(save_dir, jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_name}-err.jsonl"))
    save_path3 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_name}-miss.jsonl"))
    print(save_path1)

    infos = get_left(infos,[save_path1])
    print(f"valid: {len(infos)}")
    # single_turn(infos[0],save_path=save_path1,err_path=save_path2)
    res = []
    total=len(infos)
    parallel = 40

    single_turn_with_path = partial(single_turn, save_path=save_path1,err_path=save_path2,miss_path=save_path3)
    with ThreadPoolExecutor(max_workers=parallel) as executor:
        for output in tqdm(
                executor.map(single_turn_with_path, infos),
                total=len(infos),
                smoothing=0.1):
            pass

