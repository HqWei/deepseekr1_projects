"""对主观题进行扩写."""
import argparse
import json
import os
import random
import hashlib
import matplotlib.pyplot as plt
from openai import OpenAI
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor #多线程


from utils import *

client = OpenAI(
    api_key=api_keys['kq'],  # zq
)



def md5(data):
    """生成输入的md5值, 输入建议是`json.loads`之后的结果.

    Args:
        data: origin line after `json.loads`, list or dict.
    """
    encoded = json.dumps(data).encode()
    return hashlib.md5(encoded).hexdigest()





def make_request(messages):
    # time.sleep(5)
    completion = client.chat.completions.create(
        model='gpt-4-0125-preview',
        # model='gpt-4-1106-preview',
        # model='gpt-4-0613',
        messages=messages,
        max_tokens=4096,
        temperature=0.7,
        top_p=0.8,
    )
    return completion.choices[0].message.content



def process_batch(lines, save_file):

    with open(save_file, 'a+', encoding='utf-8') as fn:
        for line in tqdm(lines):
            source_message = json.loads(line)

            stage0 = make_request(gen_message_for_stage0(source_message))


            new_data = [{"role": "user", "content": user_content}]
            new_data.append({"role": "assistant", "content": assistant_content})

            new_info = {
                "id": md5(new_data),
                "type": source_message["类型"],
                "question_num": len(user_content),
                "ans_num": len(assistant_content),
                "data": new_data
            }

            fn.write(json.dumps(new_info, ensure_ascii=False) + '\n')

def split_data(data, batch_size):
    for i in range(0, len(data), batch_size):
        yield data[i:i + batch_size]




if __name__ == '__main__':



    source_file = '/data2/industry_project/LLM/sensechat_eval/tools/huaqiang/data/generated/roleplay-situations/roleplay-situations.jsonl'
    save_file = '/data2/industry_project/LLM/sensechat_eval/tools/huaqiang/data/generated/roleplay-situations/roleplay-situations-gpt4-generate-multi.jsonl'

    with open(source_file) as f:
        lines = f.readlines()
    threads = 10
    batch_size = len(lines) // threads + 1
    batches = list(split_data(lines, batch_size=batch_size))

    with ThreadPoolExecutor() as executor:
        executor.map(lambda batch: process_batch(batch,save_file), batches)














