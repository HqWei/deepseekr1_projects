import os
import requests
import json
import sys
from functools import partial
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
from judge_math import math_postprocess_v2, is_equiv
from grader import math_equal
import re
from openai import OpenAI
import time


def read_json(path):
    res = []
    with open(path) as f:
        for line in f:
            kptinfo = json.loads(line)

            # res.append(convert_one2qa(kptinfo))
            res.append(kptinfo)
    return res


def convert_one2qa(info):
    conversation = info["conversation"][0]
    input = conversation["input"]
    output = conversation["output"]

    tmp = input[input.find("<|im_start|>user\n") + len("<|im_start|>user\n"):]
    user_content = tmp[:tmp.find("<|im_end|>\n")]
    ans = output[:output.find("<|im_end|>")]

    data = {
        "question": user_content,
        "answer": ans
    }
    return data


def write_json(res, path):
    with open(path, 'w') as f:
        for line in res:
            f.write(json.dumps(line, ensure_ascii=False) + '\n')


internlm2_chat_sys = dict(
    SYSTEM='<|im_start|>system\n{system}<|im_end|>\n',
    INSTRUCTION=('<|im_start|>user\n{input}<|im_end|>\n'
                 '<|im_start|>assistant\n'),
    SUFFIX='<|im_end|>',
    SUFFIX_AS_EOS=True,
    SEP='\n',
    STOP_WORDS=['<|im_end|>'])


def gsm8k_postprocess(text: str) -> str:
    # text = text.split('Question:')[0]
    numbers = re.findall(r'\-?\d+\.\d+|\-?\d+', text)
    if not numbers:
        return 'NULL'
    return numbers[-1]


def extract_dollar_expressions(text):
    # __~T__~H~Y____~O~O~P~O~V~U______~O
    matches = re.findall(r'\$(.*?)\$', text)
    if matches:
        return matches[-1]
    else:
        return text


def get_gold(info):
    hints = info["hints"]
    gt = hints[-1]
    results = []
    res = extract_dollar_expressions(gt)
    results.append(res)
    res = gsm8k_postprocess(gt)
    results.append(res)
    return results


def request_openai_api(question, model_name='M1.1.2'):
    messages = [{"role": "user", "content": question}]
    openai_api_key = "EMPTY"
    openai_api_base = f"http://0.0.0.0:8000/v1"
    api_dict = {
        "served_model_name": model_name,
        "max_tokens": 30000,
        "temperature": 0.8
    }
    client = OpenAI(
        api_key=openai_api_key,
        base_url=openai_api_base,
    )
    output = None
    finish_reason = None
    API_MAX_RETRY = 2
    for _ in range(API_MAX_RETRY):
        try:
            chat_response = client.chat.completions.create(
                model=api_dict["served_model_name"],  # should consistent with deploy model name.
                messages=messages,
                max_tokens=api_dict.get("max_tokens", 16000),
                temperature=api_dict.get("temperature", 0.8),
                top_p=api_dict.get("top_p", 0.95),
                timeout=600,
                extra_body={
                    "skip_special_tokens": False}
            )
            output = chat_response.choices[0].message.content
            finish_reason = chat_response.choices[0].finish_reason
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(1.0)

    return output, finish_reason


def single_turn(info, save_path, err_path, miss_path):
    question = info["messages"][0]["content"]

    # max_try=10
    i = 1
    success = False
    while i > 0:
        try:
            response, finish_reason = request_openai_api(question)
            output = {'question': question}
            output["model_response"] = response
            # output["source_info"]=info
            output["finish_reason"] = finish_reason
            pred = math_postprocess_v2(response)
            gold = int(info["gt"])
            output["gold"] = gold
            output["pred"] = pred
            i -= 1
            success = True
            if finish_reason == 'stop':
                # success=True
                if is_equiv(pred, str(gold), version='v2') or math_equal(pred, str(gold)):
                    with open(save_path, 'a+') as fw:
                        fw.write(json.dumps(output, ensure_ascii=False) + '\n')
                        print(f"pred: {pred}, gold: {gold}, right", flush=True)
                        fw.flush()
                        return output
                else:
                    with open(err_path, 'a+') as fw:
                        fw.write(json.dumps(output, ensure_ascii=False) + '\n')
                        print(f"pred: {pred}, gold: {gold}, err", flush=True)
                        fw.flush()
            else:
                output["flag"] = 'Not stop'
                with open(miss_path, 'a+') as fw:
                    fw.write(json.dumps(output, ensure_ascii=False) + '\n')
                    print(f"No stop!", flush=True)
                    fw.flush()
        except Exception as e:
            print(e, flush=True)
            i -= 1
            continue
    if not success:
        with open(miss_path, 'a+') as fw:
            fw.write(json.dumps(info, ensure_ascii=False) + '\n')
            print(f"Miss!", flush=True)
            fw.flush()

    return 1



if __name__ == '__main__':
    ip="0.0.0.0"
    port='8000'
    url = f'http://{ip}:{port}/generate'
    headers = {'Content-Type': 'application/json'}


    # jsonl_path = '../aime/AIME_2024.jsonl'
    jsonl_path = sys.argv[1]
    model_v=sys.argv[2]
    save_dir=f'/mnt/weihuaqiang/workdirs/outputs/test_results/lightr1/{model_v}'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    infos = read_json(jsonl_path)
    #infos = infos[0::2]
    infos = infos*8
    save_path1 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_v}-right.jsonl"))
    save_path2 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_v}-err.jsonl"))
    save_path3 = os.path.join(save_dir,jsonl_path.split("/")[-1].replace(".jsonl", f"_{model_v}-miss.jsonl"))
    print(save_path1)
    #single_turn(infos[0], save_path=save_path1,err_path=save_path2)
    res = []
    total=len(infos)
    if total<60:

        parallel = total
    else:
        parallel = 60

    single_turn_with_path = partial(single_turn, save_path=save_path1,err_path=save_path2,miss_path=save_path3)
    with ThreadPoolExecutor(max_workers=parallel) as executor:
        for output in tqdm(
                executor.map(single_turn_with_path, infos),
                total=len(infos),
                smoothing=0.1):
            pass
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         205,13        Bot

