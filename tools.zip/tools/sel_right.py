import json
import os
import sys
from math_judge.judge_math import math_postprocess_v2,is_equiv
from math_judge.grader import math_equal
from tqdm import tqdm
def sel_right(json_file,save_file_right,save_file_err):
    with open(json_file) as f:
        for line in tqdm(f.readlines()):
            info=json.loads(line)
            gold = info["gold"]
            pred = info["pred"]
            if is_equiv(pred, str(gold), version='v2') or math_equal(pred, gold):
                with open(save_file_right,'a') as fn:
                    fn.write(json.dumps(info,ensure_ascii=False)+'\n')
            else:
                with open(save_file_err, 'a') as fn:
                    fn.write(json.dumps(info, ensure_ascii=False) + '\n')


json_file = '/data/data/math/gen_answer_data/deepseek_r1/MATH-train-all/MATH-train-golds.json'

save_file_right = '/data/data/math/gen_answer_data/deepseek_r1/MATH-train-all/MATH-train-golds-right.jsonl'
save_file_err = '/data/data/math/gen_answer_data/deepseek_r1/MATH-train-all/MATH-train-golds-err.jsonl'

sel_right(json_file,save_file_right,save_file_err)
