import os
import requests
import json
import sys
from functools import partial
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
from math_judge.judge_math import math_postprocess_v2,is_equiv
from math_judge.grader import math_equal
import re
from api_functions.deepseek_r1 import get_deepseek_r1
def read_json(path):
    res = []
    with open(path) as f:
        for line in f:
            kptinfo = json.loads(line)
               
            #res.append(convert_one2qa(kptinfo))
            res.append(kptinfo)
    return res

def convert_one2qa(info):
    conversation = info["conversation"][0]
    input = conversation["input"]
    output = conversation["output"]

    tmp = input[input.find("<|im_start|>user\n") + len("<|im_start|>user\n"):]
    user_content = tmp[:tmp.find("<|im_end|>\n")]
    ans = output[:output.find("<|im_end|>")]

    data = {
        "question": user_content,
        "answer": ans
    }
    return data


def write_json(res, path):
    with open(path, 'w') as f:
        for line in res:
            f.write(json.dumps(line, ensure_ascii=False) + '\n')


def gsm8k_postprocess(text: str) -> str:
    #text = text.split('Question:')[0]
    numbers = re.findall(r'\-?\d+\.\d+|\-?\d+', text)
    if not numbers:
        return 'NULL'
    return numbers[-1]

def extract_dollar_expressions(text):

    # 使用正则表达式提取数学表达式
    matches = re.findall(r'\$(.*?)\$', text)
    if matches:
        return matches[-1]
    else:
        return text

    


def single_turn(info,save_path,err_path):
    question=info["question"]
    # input = f"{question}\nPlease reason step by step, and put your final answer within " + "\\boxed{}."+"\n"
    #input = f"{question}\n请通过逐步推理来解答问题，并把最终答案放置于" + "\\boxed{}中。"+"\n"
    input = "Return your final response within \\boxed{}." + f" {question}"
    #max_try=10
    i=3
    while i>0:
        #try:
        # API_KEY = 'sk-ea80f48ddb024c0eb7a237bf2a3d9bc2'  # duomo
        API_KEY = 'sk-111b65f3c2844d07b2166487ee4cf5f7' # sense gogogo
        # print(question)
        reasoning_content,content = get_deepseek_r1(input,API_KEY = API_KEY)
        # print(content)
        pred = math_postprocess_v2(content)
        gold = info["gold"]
        output = {
            'question': question,
            'reasoning_content': reasoning_content,
            'answer_content': content,
            'source_info': info,
            'gold': info["gold"],
            'pred': pred
        }

        if is_equiv(pred, str(gold), version='v2') or math_equal(pred, gold):
            with open(save_path,'a+') as fw:
                fw.write(json.dumps(output,ensure_ascii=False)+'\n')
                print(f"pred: {pred}, gold: {gold}, right",flush=True)
                fw.flush()
                i-=1
                return output
        else:
            with open(err_path,'a+') as fw:
                fw.write(json.dumps(output,ensure_ascii=False)+'\n')
                print(f"pred: {pred}, golds: {gold}, err",flush=True)
                fw.flush()
                i-=1
                continue

                

def get_left(infos,save_paths):
    used=set()
    valid_infos=[]
    for save_path in save_paths:
        if os.path.exists(save_path):
            with open(save_path) as f:
                for line in f.readlines():
                    info=json.loads(line)
                    used.add(info["question"])
    for info in infos:
        if info["question"] in used:
            continue
        valid_infos.append(info)
    return valid_infos




if __name__ == '__main__':


    jsonl_path='/data/data/math/withgold/collect_answers/golds/GSM8K-train-golds.json'
    model_name='deepseek_r1'
    dataset_name='GSM8K'
    save_dir=f'/data/data/math/gen_answer_data/{model_name}/{dataset_name}'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    infos = read_json(jsonl_path)

    name = jsonl_path.split("/")[-1]
    basename=name[:name.rfind(".")]

    save_path1 = os.path.join(save_dir,basename+ f"_{model_name}-right.jsonl")
    save_path2 = os.path.join(save_dir,basename+ f"_{model_name}-err.jsonl")
    print(save_path1)

    infos = get_left(infos,[save_path1])
    print(f"valid: {len(infos)}")
    # single_turn(infos[0],save_path=save_path1,err_path=save_path2)
    # res = []
    total=len(infos)
    parallel = 200

    single_turn_with_path = partial(single_turn, save_path=save_path1,err_path=save_path2)
    with ThreadPoolExecutor(max_workers=parallel) as executor:
        for output in tqdm(
                executor.map(single_turn_with_path, infos),
                total=len(infos),
                smoothing=0.1):
            pass

