from openai import OpenAI

API_KEY ='sk-fea581eea5d040c8a6439f3c916bbe1a'
client = OpenAI(api_key=API_KEY, base_url="https://api.deepseek.com")

# Round 1
messages = [{"role": "user", "content": "9.11 and 9.8, which is greater?"}]
response = client.chat.completions.create(
   model="deepseek-reasoner",
   messages=messages,
   stream=True
)

reasoning_content = response.choices[0].message.reasoning_content
content = response.choices[0].message.content
print("Think: ")
print(reasoning_content)
print("Answer:")
print(content)
# Round 2
# messages.append({'role': 'assistant', 'content': content})
# messages.append({'role': 'user', 'content': "How many Rs are there in the word 'strawberry'?"})
# response = client.chat.completions.create(
#    model="deepseek-reasoner",
#    messages=messages
# )

print(content)