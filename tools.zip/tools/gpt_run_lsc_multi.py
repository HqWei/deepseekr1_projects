import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed #多线程
from time import sleep
import logging
from itertools  import repeat

GPT4_KEY = ""
import openai_proxy
# my_key = 'mZxqR1CcXVDTpr8RmEB3SYg3JynQl8pJ'
# client = openai_proxy.GptProxy(api_key=my_key)

'''
# 异步内存调用
# import openai_proxy
# import os
# api_key = 'mZxqR1CcXVDTpr8RmEB3SYg3JynQl8pJ'
# messages =  [
#     [{"role":"user", "content":"给我讲个笑话"}],
#     [{"role":"user", "content":"你是谁？"}],
#     [{"role":"user", "content":"使用我爱中国'造一个藏头诗"}],
# ]
# results, failed = openai_proxy.create_task_func_mem(api_key, "luyu_test_4323", messages, model="GPT4o_0513")
# print(results)
# print(failed)


# 同步接口调用
# import openai_proxy
# my_key = 'mZxqR1CcXVDTpr8RmEB3SYg3JynQl8pJ'
# client = openai_proxy.GptProxy(api_key=my_key)
# rsp = client.generate(
#     # messages=[{"role": "user","content": "你是一名提问专家，你要对泰国的文化提100个问题，提问方式要多样化，用泰语回答."}],
#     messages=[{"role": "user", "content": "อาหารไทยที่มีชื่อเสียงมีอะไรบ้าง?"}],
#     model="GPT4o_0513",
#     transaction_id="lsch_test_0004", # 同样transaction_id将被归类到同一个任务，一起统计
# )
# print(rsp.ok)
# if rsp.ok:
#     print(rsp.json())
# else:
#     print(rsp.text)

'''

def write_to_jsonl(sampled_data, save_json_file):
    with open(save_json_file, mode='w', encoding='utf-8') as jsonl_file:
        for line in sampled_data:
            if type(line) == str:
                jsonl_file.write(line.strip() + '\n')
            else:
                # jsonl_file.write(json.dumps(line, ensure_ascii=False) + '\n')
                json.dump(line, jsonl_file, ensure_ascii=False)
                jsonl_file.write('\n')

    print(f"finish writting {len(sampled_data)} lines")


def split_data(data, batch_size):
    for i in range(0, len(data), batch_size):
        yield data[i:i + batch_size]


def split_data_list(data, batch_size):
    res = []
    for i in range(0, len(data), batch_size):
        res.append(data[i:i + batch_size])
    return res


def read_json(source_file):
    infos = []
    with open(source_file, 'r', encoding='utf-8') as f:
        i = 1

        for line in f.readlines():
            uuid = str(i).zfill(6)
            info = json.loads(line)
            info["id"] = uuid
            infos.append(info)
            i += 1
    return infos


def read_json_generate(source_file):
    infos = []
    with open(source_file, 'r', encoding='utf-8') as f:
        i = 1

        for line in f.readlines():
            message = {}
            uuid = str(i).zfill(6)
            info = json.loads(line)
            message["id"] = uuid
            message["converation"] = info
            infos.append(message)
            i += 1
    return infos



def get_message(messages):
    converations = messages["converation"]
    for line in converations:
        if line['role'] == 'user':
            input = line['content']
            break

    system_prompt = 'คุณเป็นผู้ช่วยที่มีความรู้และคล่องแคล่วในภาษาไทย รวมทั้งเข้าใจวัฒนธรรมไทยเป็นอย่างดี เมื่อคุณตอบคำถามเป็นภาษาไทย โปรดให้คำตอบที่สะท้อนถึงมุมมองและความละเอียดอ่อนของคนไทยเจ้าของภาษา คำตอบของคุณควรเหมาะสมทางวัฒนธรรม มีรายละเอียด และพิจารณาถึงประเพณี ขนบธรรมเนียม และการแสดงออกในชีวิตประจำวันของท้องถิ่น มุ่งหวังที่จะให้คำตอบที่ถูกต้องและมีประโยชน์ที่สุดแก่ผู้ที่สงสัยเกี่ยวกับประเทศไทยจากมุมมองของคนท้องถิ่น'

    message = [{
        'role': 'system',
        'content': system_prompt
    }, {
        'role': 'user',
        'content': f"{input}"
    }]
    # print(message)
    return message, input


def translation_keyword(q_info, keyword, order):
    if keyword in q_info:
        if keyword == "evidences":
            input = q_info[keyword]
            input = input[0]["quote"]
            input = input.strip()
        else:
            if order >= 0:
                input = q_info[keyword][order]
            else:
                input = q_info[keyword]
    else:
        if keyword == 'Align':
            input = []
            input.append(q_info["question"])
            input.append(q_info["reference"])
            if "evidences" in q_info:
                if q_info["evidences"] == []:
                    input.append(q_info["evidences"])
                else:
                    input.append(q_info["evidences"][0]["quote"].strip())
            else:
                input.append([])

        else:
            print(f'{keyword} not in message')

    system_prompt = '''你是一位精通中文和泰语的专业翻译。你的任务是将复杂文本从中文翻译成泰语。
        1. 保持所有公式和代码片段不变并准确格式化。
        2. 将专业术语和行业术语翻译为相应的泰语等价词。
        3. 确保翻译清晰准确，并保持原意和上下文不变。
        4. 如果是表情，保持和原有表情不变。
        5. 不要去理解输入，不要对输入进行回答，直接翻译。'''

    # system_prompt = '''You are an expert translator proficient in both English and Thai. Your task is to translate complex texts from English to Thai.
    #     1. Keep all formulas, code snippets and input formats unchanged and accurately formatted.
    #     2. Translate specialized terms and professional jargon to their appropriate Thai equivalents.
    #     3. Ensure the translation is clear, accurate, and maintains the original meaning and context. '''

    message = [{
        'role': 'system',
        'content': system_prompt
    }, {
        'role': 'user',
        'content': f"把下面的输入翻译成中文。注意，不要回答问题。 \n{input}"
    #     'content': f"Translate the following English text into Thai. Do not anwser the question. \n{input}"
    }]
    # print(message)
    return message, input


def process_batch_benchmark(lines, save_file, name, client, save_file_miss):

    with open(save_file_miss, 'a+', encoding='utf-8') as fm:
        with open(save_file, 'a+', encoding='utf-8') as fn:
            max_retries = 3
            i = 0

            for messages in lines:
                # mes_copy = messages
                print(i)
                i += 1
                sleep(0.1)  # Be mindful of rate limits
                logging.info(f'Generating {i}-th message')
                attempt = 0

                while attempt < max_retries:
                    try:
                        '''
                        # mt_bench
                        thai_turns = []
                        order = -1
                        input_q, input_mq = translation_keyword(messages, "reference", order)
                        stage0, finish_reason_q = make_request_old(input_q, name, api_keys)
                        thai_turns = stage0

                        new_info = {
                            "id": messages["id"],
                            "attempt": attempt,
                            "finish_reason": finish_reason_q,
                            "gpt4_response": mes_copy["gpt4_response"],
                            "gpt4_reference": thai_turns,
                            "source_message": messages,
                            "gpt_version": name
                        }
                        '''

                        # AlignBench
                        order = -1
                        message, input_mq = translation_keyword(messages, "Align", order)
                        # print(stage0)

                        rsp = client.generate(
                            messages=message,
                            model="GPT4o_0513",
                            transaction_id="Alignbench",  # 同样transaction_id将被归类到同一个任务，一起统计
                            temperature=0.7,  # 0.8
                            max_tokens=4096,
                            top_p=0.95,  # 0.9
                            frequency_penalty=0,
                            presence_penalty=0,
                            stop=None
                        )
                        # print(messages)

                        # if rsp.ok:
                        response_content = eval(rsp.json()['data']['response_content'])
                        finish_reason = response_content['choices'][0]['finish_reason']
                        response = response_content['choices'][0]['message']['content']
                        output = eval(response)
                        # assistant = eval(rsp.json()['data']['response_content'])['choices'][0]['message']['content']

                        new_info = {
                            "id": messages["id"],
                            "attempt": attempt,
                            "finish_reason": finish_reason,
                            "gpt4_question": output[0],
                            "gpt4_answer": output[1],
                            "gpt4_quote": output[2],
                            "source_message": messages,
                            "gpt_version": 'GPT4o_0513'
                        }

                        fn.write(json.dumps(new_info, ensure_ascii=False) + '\n')
                        # continue

                        # Check if the response is valid
                        if finish_reason != "stop" or '抱歉' in response or '对不起' in response or '重新' in response or '无法回答' in response or len(response) < 10:
                            logging.info("Refuse to respond or response too short")
                            attempt += 1
                            continue  # Skip aving this response

                        break
                    except Exception as e:
                        logging.error(f"Attempt {attempt + 1}: Error in API call - {e}")
                        attempt += 1
                        sleep(1)
                if attempt >= max_retries:
                    fm.write(json.dumps(messages,ensure_ascii=False)+'\n')
                    logging.error("Error generating response after multiple attempts")


def process_batch_generate(lines, save_file, save_file_miss):
    my_key = 'mZxqR1CcXVDTpr8RmEB3SYg3JynQl8pJ'
    client = openai_proxy.GptProxy(api_key=my_key)

    with open(save_file_miss, 'a+', encoding='utf-8') as fm:
        with open(save_file, 'a+', encoding='utf-8') as fn:
            max_retries = 3
            i = 0

            for messages in lines:
                # mes_copy = messages
                print(i)
                i += 1
                sleep(0.1)  # Be mindful of rate limits
                logging.info(f'Generating {i}-th message')
                attempt = 0

                while attempt < max_retries:
                    try:
                        message, input_mq = get_message(messages)
                        # print(stage0)

                        rsp = client.generate(
                            messages=message,
                            model="GPT4o_0513",
                            transaction_id="Thai_context",  # 同样transaction_id将被归类到同一个任务，一起统计
                            temperature=0.7,  # 0.8
                            max_tokens=4096,
                            top_p=0.95,  # 0.9
                            frequency_penalty=0,
                            presence_penalty=0,
                            stop=None
                        )
                        # print(messages)

                        # if rsp.ok:
                        response_content = eval(rsp.json()['data']['response_content'])
                        finish_reason = response_content['choices'][0]['finish_reason']
                        response = response_content['choices'][0]['message']['content']
                        # assistant = eval(rsp.json()['data']['response_content'])['choices'][0]['message']['content']

                        new_info = {
                            "id": messages["id"],
                            "attempt": attempt,
                            "finish_reason": finish_reason,
                            "gpt4_response": response,
                            "source_message": messages,
                            "gpt_version": 'GPT4o_0513'
                        }

                        fn.write(json.dumps(new_info, ensure_ascii=False) + '\n')
                        # continue

                        # Check if the response is valid
                        if finish_reason != "stop" or '抱歉' in response or '对不起' in response or '重新' in response or '无法回答' in response or len(response) < 10:
                            logging.info("Refuse to respond or response too short")
                            attempt += 1
                            continue  # Skip aving this response

                        break
                    except Exception as e:
                        logging.error(f"Attempt {attempt + 1}: Error in API call - {e}")
                        attempt += 1
                        sleep(0.3)
                if attempt >= max_retries:
                    fm.write(json.dumps(messages,ensure_ascii=False)+'\n')
                    logging.error("Error generating response after multiple attempts")

            return 1


if __name__ == '__main__':

    # single_file_demo()

    file_dir = 'in'
    save_dir = 'out'
    os.makedirs(save_dir, exist_ok=True)

    for root, dirs, files in os.walk(file_dir):
        for file_name in files:
            if file_name.endswith(".jsonl") and '7' not in file_name:

                source_file = os.path.join(file_dir, file_name)
                name = os.path.splitext(file_name)[0]
                save_file = os.path.join(save_dir, name + '-GPT4o.jsonl')
                save_file_err = os.path.join(save_dir, name + '-GPT4o-err.jsonl')
                save_file_miss = os.path.join(save_dir, name + '-GPT4o-miss.jsonl')

                texts = read_json_generate(source_file)
                print(f"Processing {file_name}, Total: {len(texts)}")

                
                threads = 2
                with ThreadPoolExecutor(max_workers=threads) as executor:
                # with ProcessPoolExecutor(max_workers=threads) as executor:

                    sub_text = texts

                    
                    batch_size = len(sub_text) // threads
                    batches = list(split_data(sub_text, batch_size=batch_size))

                    # executor.map(lambda batch: process_batch_benchmark(batch, save_file, name, client,
                    #                                                    save_file_miss), batches)
                    futures = [executor.submit(process_batch_generate, batch, save_file, save_file_miss) for batch in batches]
                        

                    for future in as_completed(futures):
                        result = future.result()
                    
